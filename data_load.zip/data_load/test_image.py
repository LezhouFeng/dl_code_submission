from PIL import Image
import numpy as np 

MICCAI_IMAGE1 = '/home/flz/MICCAI2018_EndoVis_Challenge/miccai_challenge_2018_release_1/seq_1/labels/frame000.png'
MICCAI_IMAGE2 = '/home/flz/MICCAI2018_EndoVis_Challenge/miccai_challenge_2018_release_1/seq_4/labels/frame051.png'
VOC_IMAGE = ''

MICCAI_CLASSES = [(0, 0, 0, 255)]
class_map = dict(zip(MICCAI_CLASSES, range(10,100)))

# rgba = Image.open(MICCAI_IMAGE)
# print(rgba)
# # print(list(rgba.getdata()))
# print(rgba.getpalette())
p1 = Image.open(MICCAI_IMAGE2).convert('L')
print(list(p1.getdata()))
p1_array = np.array(p1)
print(p1_array.shape)